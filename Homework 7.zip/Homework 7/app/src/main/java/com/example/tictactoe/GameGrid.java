package com.example.tictactoe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class GameGrid extends AppCompatActivity {

    public static String p1;
    public static String p2;
    TextView turn;
    Boolean player1Turn=true;
    int roundCounter = 0;
    public static int[][] table = new int[3][3];
    public static int maxTime = 15000, interval =1000;
    public static int count = maxTime/interval;
    public static CountDownTimer cdt;
    String id;
    ImageButton chosen;
    Button stopAndSave;
    String stText="";
    String stPreviousText="";
    String currentPlayer;
    static String result="result";
    private FileOutputStream fos;
    private OutputStreamWriter osw;
    private BufferedWriter bw;
    static String isResuming;
    Intent intent;
    int i;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_grid);

        TableValues();
        intent = getIntent();
        isResuming = intent.getStringExtra(MainActivity.isResuming);
        if (isResuming != null){
            if (isResuming.equals("T")){
                CheckPrevious();}}
        if (p1==null)
            p1 = intent.getStringExtra(NewGame.P1);
        if (p2==null)
            p2 = intent.getStringExtra(NewGame.P2);
        stopAndSave = (Button) findViewById(R.id.stop);
        turn = (TextView) findViewById(R.id.playerTurn);
        turn.setText(p1 + " Turn");

        stopAndSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                File myDir = new File("data/data/"+getPackageName()+"/txtFile");
                myDir.mkdir();
                File myFile1= new File(myDir,"previous");
                File myFile2= new File(myDir,"participants");
                try {
                    fos = new FileOutputStream(myFile1);
                    osw=new OutputStreamWriter(fos);
                    bw = new BufferedWriter(osw);
                    bw.write(stPreviousText);
                    bw.close();
                } catch (FileNotFoundException e) {
                    Toast.makeText(GameGrid.this,"ERROR",Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    Toast.makeText(GameGrid.this,"ERROR",Toast.LENGTH_LONG).show();
                }
                try {
                    fos = new FileOutputStream(myFile2);
                    osw=new OutputStreamWriter(fos);
                    bw = new BufferedWriter(osw);
                    bw.write(p1 +"\n"+p2);
                    bw.close();
                } catch (FileNotFoundException e) {
                    Toast.makeText(GameGrid.this,"ERROR",Toast.LENGTH_LONG).show();
                } catch (IOException e) {
                    Toast.makeText(GameGrid.this,"ERROR",Toast.LENGTH_LONG).show();
                }
                finishAffinity();
                System.exit(0);
            }
        });
    }
    public void onClick (View view){
                chosen = (ImageButton) view;

                if (player1Turn){
                    chosen.setImageResource(R.drawable.x);
                i=1;}
                else{
                    chosen.setImageResource(R.drawable.o);
                i=2;}
                roundCounter++;
                currentPlayer = CurrentPlayer(player1Turn);
                id = FindByIntId(view.getId());
                stPreviousText += id+ "\n";
                stText += roundCounter +". " +currentPlayer+ " marked square "+ id+" \n";
                FindPlacementById(i);
                if (CheckColumns(i)||CheckRows(i)||CheckDiagonal(i)) {//Either player won
                    finish();
                    stText += " And won!! ";
                   Toast.makeText(GameGrid.this, currentPlayer + " won!!", Toast.LENGTH_LONG).show();
                   Toast.makeText(GameGrid.this, "Thanks for playing. See you next time! ", Toast.LENGTH_LONG).show();
                   EndGame();
                   intent = new Intent(GameGrid.this, EndScreen.class);
                   intent.putExtra(result,stText);
                   startActivity(intent);
                }
                else if (roundCounter >= 9) {//Tie
                    stText += " And it ended as a tie";
                    Toast.makeText(GameGrid.this, "Its a tie!!", Toast.LENGTH_LONG).show();
                    Toast.makeText(GameGrid.this, "Thanks for playing. See you next time! ", Toast.LENGTH_LONG).show();
                    EndGame();
                    intent = new Intent(GameGrid.this, EndScreen.class);
                    intent.putExtra(result,stText);
                    startActivity(intent);
                }
                else {
                    if (player1Turn) {
                        player1Turn = false;
                        turn.setText(p2 + " Turn");
                    }
                    else {
                        player1Turn = true;
                        turn.setText(p1 + " Turn");
                    }
                }
            }
    public static void TableValues() {
        for (int i = 0; i < table.length; i++) {
            for (int g=0; g< table[i].length;g++)
                    table[i][g] = 0;
            }
        }
    public static boolean CheckColumns(int i) {
        for (int j = 0; j < 3; j++){
            if ((table[0][j] == i && table[1][j] == i && table[2][j] == i)) {
                return true;
            }
        }
        return false;
    }
    public static boolean CheckRows(int i){
        for (int j = 0; j < 3; j++) {
            if ((table[j][0] == i && table[j][1] == i && table[j][2] == i)) {
                return true;
            }
        }
        return false;
    }
    public static boolean CheckDiagonal(int i){
        if ((table[0][0] == i && table[1][1] == i && table[2][2] == i) ||(table[0][2] == i && table[1][1] == i && table[2][0] == i)) {
            return true;
        }
        return false;
    }
    public static String CurrentPlayer(boolean player1Turn) {
        if (player1Turn)
            return p1;
        else
            return p2;
    }
    public String FindByIntId(int id){
        if (id == R.id.zeroZero){
            return "zeroZero";}
        else if (id == R.id.zeroOne){
            return "zeroOne";}
        else if (id == R.id.zeroTwo){
            return "zeroTwo";}
        else if (id == R.id.oneZero){
            return "oneZero";}
        else if (id == R.id.oneOne){
            return "oneOne";}
        else if (id == R.id.oneTwo){
            return "oneTwo";}
        else if (id == R.id.twoZero){
            return "twoZero";}
        else if (id == R.id.twoOne){
            return "twoOne";}
        else if (id == R.id.twoTwo){
            return "twoTwo";}
        return "";
    }
    public void SetImageByStringId(int i){
        if (id != null) {
            if (id.equals("zeroZero")) {
                chosen = (ImageButton) findViewById(R.id.zeroZero);
                if (i == 1)
                    chosen.setImageResource(R.drawable.x);
                else if (i == 2)
                    chosen.setImageResource(R.drawable.o);
            } else if (id.equals("zeroOne")) {
                chosen = (ImageButton) findViewById(R.id.zeroOne);
                if (i == 1)
                    chosen.setImageResource(R.drawable.x);
                else if (i == 2)
                    chosen.setImageResource(R.drawable.o);
            } else if (id.equals("zeroTwo")) {
                chosen = (ImageButton) findViewById(R.id.zeroTwo);
                if (i == 1)
                    chosen.setImageResource(R.drawable.x);
                else if (i == 2)
                    chosen.setImageResource(R.drawable.o);
            } else if (id.equals("oneZero")) {
                chosen = (ImageButton) findViewById(R.id.oneZero);
                if (i == 1)
                    chosen.setImageResource(R.drawable.x);
                else if (i == 2)
                    chosen.setImageResource(R.drawable.o);
            } else if (id.equals("oneOne")){
                chosen = (ImageButton) findViewById(R.id.oneOne);
                if (i == 1)
                    chosen.setImageResource(R.drawable.x);
                else if (i == 2)
                    chosen.setImageResource(R.drawable.o);
            } else if (id.equals("oneTwo")) {
                chosen = (ImageButton) findViewById(R.id.oneTwo);
                if (i == 1)
                    chosen.setImageResource(R.drawable.x);
                else if (i == 2)
                    chosen.setImageResource(R.drawable.o);
            } else if (id.equals("twoZero")) {
                chosen = (ImageButton) findViewById(R.id.twoZero);
                if (i == 1)
                    chosen.setImageResource(R.drawable.x);
                else if (i == 2)
                    chosen.setImageResource(R.drawable.o);
            } else if (id.equals("twoOne")) {
                chosen = (ImageButton) findViewById(R.id.twoOne);
                if (i == 1)
                    chosen.setImageResource(R.drawable.x);
                else if (i == 2)
                    chosen.setImageResource(R.drawable.o);
            } else if (id.equals("twoTwo")) {
                chosen = (ImageButton) findViewById(R.id.twoTwo);
                if (i == 1)
                    chosen.setImageResource(R.drawable.x);
                else if (i == 2)
                    chosen.setImageResource(R.drawable.o);
            }
        }
    }
    private void FindPlacementById(int i) {
        if (id != null) {
            if (id.equals("zeroZero")) {
                table[0][0] = i;
            } else if (id.equals("zeroOne")) {
                table[0][1] = i;
            } else if (id.equals("zeroTwo")){
                table[0][2] = i;
            } else if (id.equals("oneZero")) {
                table[1][0] = i;
            } else if (id.equals("oneOne")) {
                table[1][1] = i;
            } else if (id.equals("oneTwo")) {
                table[1][2] = i;
            } else if (id.equals( "twoZero")) {
                table[2][0] = i;
            } else if (id.equals( "twoOne")) {
                table[2][1] = i;
            } else if (id.equals( "twoTwo")){
                table[2][2] = i;
            }
        }
    }
    public void EndGame(){
        cdt=new CountDownTimer(maxTime,interval) {
            @Override
            public void onTick(long millisUntilFinished) {
                count--;
            }

            @Override
            public void onFinish() {
                finish();//Close App
                System.exit(0);
            }
        }.start();
        File myDir = new File("data/data/"+getPackageName()+"/txtFile");
        myDir.mkdir();
        File myFile= new File(myDir,"results");
        try {
            fos = new FileOutputStream(myFile);
            osw=new OutputStreamWriter(fos);
            bw = new BufferedWriter(osw);
            bw.write(stText);
            bw.close();
        } catch (FileNotFoundException e) {
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();
        }
    }
    public void CheckPrevious(){
        File file1 = new File("data/data/"+getPackageName()+ "/txtFile/","participants");//Previous participants
        try {
            FileInputStream fis= new FileInputStream(String.valueOf(file1));
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine())!=null){
                sb.append(line+"\n");
                if (player1Turn){
                    p1= line;
                    player1Turn = false;}
                else {
                    p2= line;
                    player1Turn = true;}
            }
        } catch (FileNotFoundException e) {
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();
        }

        File file2 = new File("data/data/"+getPackageName()+ "/txtFile/","previous");//Previous moves
        try {
            FileInputStream fis= new FileInputStream(String.valueOf(file2));
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            while ((id = br.readLine())!=null){
                if (player1Turn){
                    roundCounter++;
                    stText += roundCounter +". " +p1+ " marked square "+ id+" \n";
                    FindPlacementById(1);
                    SetImageByStringId(1);
                    player1Turn=false;
                }
                else{
                    roundCounter++;
                    stText += roundCounter +". " +p2+ " marked square "+ id+" \n";
                    FindPlacementById(2);
                    SetImageByStringId(2);
                    player1Turn=true;
                }
            }
            br.close();
        } catch (FileNotFoundException e) {
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();
        }
    }
}

