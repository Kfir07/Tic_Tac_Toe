package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class EndScreen extends AppCompatActivity {
    TextView resultBySteps;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_screen);

        Intent intent = getIntent();
        String Results = intent.getStringExtra(GameGrid.result);
        resultBySteps = (TextView) findViewById(R.id.results);
        File file = new File("data/data/"+getPackageName()+ "/txtFile/","results");
        try {
            FileInputStream fis= new FileInputStream(String.valueOf(file));
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine())!=null){
                sb.append(line+"\n");
            }
            String fileContents = sb.toString();
            resultBySteps.setText(fileContents);
            br.close();
        } catch (FileNotFoundException e) {
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();
        }
    }
}