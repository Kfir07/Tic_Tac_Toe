package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    Button newGame, resumeGame;
    Intent intent;
    static String isResuming = "T";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newGame = (Button) findViewById(R.id.newGame);
        resumeGame = (Button) findViewById(R.id.resumeGame);

        newGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(MainActivity.this, NewGame.class);
                startActivity(intent);
            }
        });
        resumeGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (DoesGameExists()) {
                    intent = new Intent(MainActivity.this, GameGrid.class);
                    String value = "T";
                    intent.putExtra(isResuming, value);
                    startActivity(intent);
                }
            }
        });
    }
    public boolean DoesGameExists(){
        boolean exists= true;
        File file1 = new File("data/data/"+getPackageName()+ "/txtFile/","previous");//Previous participants
        try {
            FileInputStream fis= new FileInputStream(String.valueOf(file1));
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            if (br.readLine()==null){
                exists=false;
            }
        } catch (FileNotFoundException e) {
            Toast.makeText(MainActivity.this, "There is no previous game saved, Please start a new game",Toast.LENGTH_SHORT).show();
            exists=false;
        } catch (IOException e) {
            Toast.makeText(MainActivity.this, "There is no previous game saved, Please start a new game",Toast.LENGTH_SHORT).show();
            exists=false;
        }
        return exists;
    }
}