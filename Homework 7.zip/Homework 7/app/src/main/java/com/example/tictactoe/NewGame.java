package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class NewGame extends AppCompatActivity {
    Button next;
    EditText p1,p2;
    InputStream is;
    InputStreamReader isr;
    BufferedReader br;
    String st,all = "";
    TextView welcomeMessage;
    public static String P1 = "player1",P2="player2";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_game);

        welcomeMessage = (TextView) findViewById(R.id.welcome);
        is=getResources().openRawResource(R.raw.txt);
        isr= new InputStreamReader(is);
        br = new BufferedReader(isr);
        try {
            while (((st=br.readLine())!= null))
                all+=st+"\n";
            br.close();
        } catch (IOException e){
            Toast.makeText(this,"ERROR",Toast.LENGTH_SHORT).show();}
        welcomeMessage.setText(all);
        next= (Button) findViewById(R.id.next);
        p1 = (EditText) findViewById(R.id.player1);
        p2 = (EditText) findViewById(R.id.player2);
        next.setOnClickListener(
                new View.OnClickListener(){//Listener - when the button is pressed
                    @Override
                    public void onClick(View view) {
                        Intent intent = new Intent(NewGame.this,GameGrid.class);//Intent creation between MainActivity and FirstActivity
                        String player1 = p1.getText().toString();
                        String player2 = p2.getText().toString();
                        intent.putExtra(P1, player1);
                        intent.putExtra(P2, player2);
                        startActivity(intent);//Intent initiating
                    }
                });

            }
    }